# Games 360 - TODO

## Schema & Backend
- [x] Schema: tabela `games` (id, title, description, categoryId, coverUrl, coverKey, downloadUrl, featured, createdAt, updatedAt)
- [x] Schema: tabela `categories` (id, name, slug, createdAt)
- [x] Migration SQL aplicada via webdev_execute_sql
- [x] DB helpers: getGames, getGameById, getCategories, etc.
- [x] tRPC: games.list (com filtro por categoria e pesquisa)
- [x] tRPC: games.featured (jogos recomendados)
- [x] tRPC: games.getById
- [x] tRPC: games.create (admin)
- [x] tRPC: games.update (admin)
- [x] tRPC: games.delete (admin)
- [x] tRPC: categories.list
- [x] tRPC: categories.create (admin)
- [x] tRPC: categories.update (admin)
- [x] tRPC: categories.delete (admin)
- [x] tRPC: upload.coverImage (base64 → S3) (admin, para upload de capa S3)
- [x] Notificação ao proprietário ao adicionar novo jogo

## Frontend Público
- [x] Design system brutalista: fundo preto, tipografia branca condensada, linha vermelha
- [x] index.css com tokens de cor e fontes (Bebas Neue / Inter)
- [x] Navbar com logo, pesquisa e link para login ADM
- [x] Home: hero brutalista com título impactante e linha vermelha
- [x] Seção de jogos recomendados (featured)
- [x] Listagem de jogos com cards (capa, título, categoria, botão download)
- [x] Filtro por categoria (tabs/botões)
- [x] Barra de pesquisa funcional
- [x] Página de detalhes do jogo
- [x] Página de categoria (via filtro na home)
- [x] Estado vazio e loading skeletons

## Painel ADM
- [x] Rota /admin protegida (apenas role=admin)
- [x] Login via Manus OAuth com promoção automática do owner a admin
- [x] Dashboard ADM com tabs (jogos/categorias)
- [x] Listagem de jogos no ADM com ações editar/remover
- [x] Modal/formulário para adicionar jogo (título, descrição, categoria, link download, upload capa)
- [x] Modal/formulário para editar jogo
- [x] Confirmação de remoção de jogo
- [x] Listagem de categorias no ADM
- [x] Formulário para adicionar/editar/remover categoria
- [x] Upload de imagem de capa direto para S3

## Testes
- [x] Vitest: games CRUD procedures
- [x] Vitest: categories CRUD procedures
