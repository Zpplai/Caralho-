import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock db module
vi.mock("./db", () => ({
  getGames: vi.fn().mockResolvedValue([]),
  getFeaturedGames: vi.fn().mockResolvedValue([]),
  getGameById: vi.fn().mockResolvedValue({ id: 1, title: "Test Game", createdAt: new Date() }),
  createGame: vi.fn().mockResolvedValue({}),
  updateGame: vi.fn().mockResolvedValue({}),
  deleteGame: vi.fn().mockResolvedValue({}),
  getCategories: vi.fn().mockResolvedValue([]),
  createCategory: vi.fn().mockResolvedValue({}),
  updateCategory: vi.fn().mockResolvedValue({}),
  deleteCategory: vi.fn().mockResolvedValue({}),
}));

vi.mock("./_core/notification", () => ({
  notifyOwner: vi.fn().mockResolvedValue(true),
}));

vi.mock("./storage", () => ({
  storagePut: vi.fn().mockResolvedValue({ url: "https://cdn.example.com/img.jpg", key: "covers/test.jpg" }),
}));

function makeCtx(role: "admin" | "user" | null = null): TrpcContext {
  const user = role
    ? {
        id: 1,
        openId: "test-user",
        name: "Test",
        email: "test@example.com",
        loginMethod: "manus",
        role,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      }
    : null;

  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("games.list", () => {
  it("returns empty array for public user", async () => {
    const caller = appRouter.createCaller(makeCtx(null));
    const result = await caller.games.list({});
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("games.featured", () => {
  it("returns featured games", async () => {
    const caller = appRouter.createCaller(makeCtx(null));
    const result = await caller.games.featured();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("games.getById", () => {
  it("returns game by id", async () => {
    const caller = appRouter.createCaller(makeCtx(null));
    const result = await caller.games.getById({ id: 1 });
    expect(result).toHaveProperty("id", 1);
  });
});

describe("games.create (admin only)", () => {
  it("throws FORBIDDEN for non-admin", async () => {
    const caller = appRouter.createCaller(makeCtx("user"));
    await expect(caller.games.create({ title: "Test" })).rejects.toThrow();
  });

  it("creates game for admin", async () => {
    const caller = appRouter.createCaller(makeCtx("admin"));
    const result = await caller.games.create({ title: "New Game" });
    expect(result).toEqual({ success: true });
  });
});

describe("games.delete (admin only)", () => {
  it("throws FORBIDDEN for non-admin", async () => {
    const caller = appRouter.createCaller(makeCtx("user"));
    await expect(caller.games.delete({ id: 1 })).rejects.toThrow();
  });

  it("deletes game for admin", async () => {
    const caller = appRouter.createCaller(makeCtx("admin"));
    await expect(caller.games.delete({ id: 1 })).resolves.not.toThrow();
  });
});

describe("categories.list", () => {
  it("returns categories publicly", async () => {
    const caller = appRouter.createCaller(makeCtx(null));
    const result = await caller.categories.list();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("categories.create (admin only)", () => {
  it("throws FORBIDDEN for non-admin", async () => {
    const caller = appRouter.createCaller(makeCtx("user"));
    await expect(caller.categories.create({ name: "Ação", slug: "acao" })).rejects.toThrow();
  });

  it("creates category for admin", async () => {
    const caller = appRouter.createCaller(makeCtx("admin"));
    await expect(caller.categories.create({ name: "Ação", slug: "acao" })).resolves.not.toThrow();
  });
});
