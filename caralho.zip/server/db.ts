import { and, eq, ilike, like, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { categories, games, InsertCategory, InsertGame, InsertUser, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    const value = user[field];
    if (value === undefined) continue;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  }

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }

  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

// ─── Categories ───────────────────────────────────────────────────────────────

export async function getCategories() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(categories).orderBy(categories.name);
}

export async function getCategoryBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(categories).where(eq(categories.slug, slug)).limit(1);
  return result[0];
}

export async function createCategory(data: InsertCategory) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(categories).values(data);
  return result;
}

export async function updateCategory(id: number, data: Partial<InsertCategory>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(categories).set(data).where(eq(categories.id, id));
}

export async function deleteCategory(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  // Unlink games from this category first
  await db.update(games).set({ categoryId: null }).where(eq(games.categoryId, id));
  await db.delete(categories).where(eq(categories.id, id));
}

// ─── Games ────────────────────────────────────────────────────────────────────

export async function getGames(opts?: { categoryId?: number; search?: string }) {
  const db = await getDb();
  if (!db) return [];

  const conditions = [];
  if (opts?.categoryId) conditions.push(eq(games.categoryId, opts.categoryId));
  if (opts?.search) conditions.push(like(games.title, `%${opts.search}%`));

  const rows = await db
    .select({
      id: games.id,
      title: games.title,
      description: games.description,
      coverUrl: games.coverUrl,
      downloadUrl: games.downloadUrl,
      featured: games.featured,
      createdAt: games.createdAt,
      updatedAt: games.updatedAt,
      categoryId: games.categoryId,
      categoryName: categories.name,
      categorySlug: categories.slug,
    })
    .from(games)
    .leftJoin(categories, eq(games.categoryId, categories.id))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(games.createdAt);

  return rows;
}

export async function getFeaturedGames() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: games.id,
      title: games.title,
      description: games.description,
      coverUrl: games.coverUrl,
      downloadUrl: games.downloadUrl,
      featured: games.featured,
      createdAt: games.createdAt,
      updatedAt: games.updatedAt,
      categoryId: games.categoryId,
      categoryName: categories.name,
      categorySlug: categories.slug,
    })
    .from(games)
    .leftJoin(categories, eq(games.categoryId, categories.id))
    .where(eq(games.featured, true))
    .limit(6);
}

export async function getGameById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select({
      id: games.id,
      title: games.title,
      description: games.description,
      coverUrl: games.coverUrl,
      coverKey: games.coverKey,
      downloadUrl: games.downloadUrl,
      featured: games.featured,
      createdAt: games.createdAt,
      updatedAt: games.updatedAt,
      categoryId: games.categoryId,
      categoryName: categories.name,
      categorySlug: categories.slug,
    })
    .from(games)
    .leftJoin(categories, eq(games.categoryId, categories.id))
    .where(eq(games.id, id))
    .limit(1);
  return result[0];
}

export async function createGame(data: InsertGame) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(games).values(data);
  return result;
}

export async function updateGame(id: number, data: Partial<InsertGame>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(games).set(data).where(eq(games.id, id));
}

export async function deleteGame(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(games).where(eq(games.id, id));
}
