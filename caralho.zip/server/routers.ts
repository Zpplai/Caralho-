import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { notifyOwner } from "./_core/notification";
import {
  createCategory,
  createGame,
  deleteCategory,
  deleteGame,
  getCategories,
  getGameById,
  getGames,
  getFeaturedGames,
  updateCategory,
  updateGame,
} from "./db";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";

// Admin guard middleware
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Acesso restrito a administradores." });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  categories: router({
    list: publicProcedure.query(() => getCategories()),

    create: adminProcedure
      .input(z.object({ name: z.string().min(1), slug: z.string().min(1) }))
      .mutation(({ input }) => createCategory(input)),

    update: adminProcedure
      .input(z.object({ id: z.number(), name: z.string().min(1).optional(), slug: z.string().min(1).optional() }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return updateCategory(id, data);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => deleteCategory(input.id)),
  }),

  games: router({
    list: publicProcedure
      .input(z.object({ categoryId: z.number().optional(), search: z.string().optional() }).optional())
      .query(({ input }) => getGames(input)),

    featured: publicProcedure.query(() => getFeaturedGames()),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const game = await getGameById(input.id);
        if (!game) throw new TRPCError({ code: "NOT_FOUND" });
        return game;
      }),

    create: adminProcedure
      .input(
        z.object({
          title: z.string().min(1),
          description: z.string().optional(),
          categoryId: z.number().optional(),
          coverUrl: z.string().optional(),
          coverKey: z.string().optional(),
          downloadUrl: z.string().optional(),
          featured: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        await createGame(input);
        await notifyOwner({
          title: "Novo jogo adicionado",
          content: `O jogo "${input.title}" foi adicionado ao catálogo Games 360.`,
        });
        return { success: true };
      }),

    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          title: z.string().min(1).optional(),
          description: z.string().optional(),
          categoryId: z.number().nullable().optional(),
          coverUrl: z.string().optional(),
          coverKey: z.string().optional(),
          downloadUrl: z.string().optional(),
          featured: z.boolean().optional(),
        })
      )
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return updateGame(id, data);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => deleteGame(input.id)),
  }),

  upload: router({
    coverImage: adminProcedure
      .input(
        z.object({
          filename: z.string(),
          contentType: z.string(),
          base64: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        const ext = input.filename.split(".").pop() ?? "jpg";
        const key = `covers/${nanoid()}.${ext}`;
        const buffer = Buffer.from(input.base64, "base64");
        const { url } = await storagePut(key, buffer, input.contentType);
        return { url, key };
      }),
  }),
});

export type AppRouter = typeof appRouter;
