import { getStorage } from "firebase/storage";
import { getApp } from "firebase/app";

// Reutilizar a mesma instância do app inicializada em firebase.ts
const app = getApp();
export const storage = getStorage(app);
