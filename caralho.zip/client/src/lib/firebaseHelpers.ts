import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  getDocs,
  query,
  where,
  orderBy,
  QueryConstraint,
} from "firebase/firestore";
import { db } from "./firebase";

export interface User {
  uid: string;
  email?: string;
  displayName?: string;
  role: "admin" | "user";
}

export interface Game {
  id: string;
  title: string;
  description: string;
  categoryId: string;
  categoryName?: string;
  coverUrl: string;
  downloadUrl: string;
  featured: boolean;
  createdAt: number;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  createdAt: number;
}

// ─── Users ────────────────────────────────────────────────────────────────────
const ADMIN_WHITELIST = ["thiagofernandesribeirosalvss@gmail.com"];

export async function getUserRole(uid: string, email?: string): Promise<"admin" | "user"> {
  try {
    // Verificar email whitelist primeiro
    if (email && ADMIN_WHITELIST.includes(email)) {
      return "admin";
    }
    // Fallback para verificar collection admins
    const snapshot = await getDocs(query(collection(db, "admins"), where("uid", "==", uid)));
    return snapshot.empty ? "user" : "admin";
  } catch {
    return "user";
  }
}

export async function setUserAsAdmin(uid: string): Promise<void> {
  try {
    await addDoc(collection(db, "admins"), { uid, createdAt: Date.now() });
  } catch (e) {
    console.error("Erro ao promover admin:", e);
  }
}

// ─── Games ────────────────────────────────────────────────────────────────────
export async function getGames(opts?: { categoryId?: string; search?: string }): Promise<Game[]> {
  const constraints: QueryConstraint[] = [];

  if (opts?.categoryId) {
    constraints.push(where("categoryId", "==", opts.categoryId));
  }

  constraints.push(orderBy("createdAt", "desc"));

  const q = query(collection(db, "games"), ...constraints);
  const snapshot = await getDocs(q);

  let games = snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
  } as Game));

  if (opts?.search) {
    const searchLower = opts.search.toLowerCase();
    games = games.filter((g) => g.title.toLowerCase().includes(searchLower));
  }

  return games;
}

export async function getFeaturedGames(): Promise<Game[]> {
  const q = query(
    collection(db, "games"),
    where("featured", "==", true),
    orderBy("createdAt", "desc")
  );
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Game)).slice(0, 6);
}

export async function getGameById(id: string): Promise<Game | null> {
  const snapshot = await getDocs(query(collection(db, "games"), where("__name__", "==", id)));
  if (snapshot.empty) return null;
  const data = snapshot.docs[0].data();
  return { id: snapshot.docs[0].id, ...data } as Game;
}

export async function createGame(gameData: Omit<Game, "id" | "createdAt">): Promise<string> {
  const docRef = await addDoc(collection(db, "games"), {
    ...gameData,
    createdAt: Date.now(),
  });
  return docRef.id;
}

export async function updateGame(id: string, gameData: Partial<Game>): Promise<void> {
  const docRef = doc(db, "games", id);
  await updateDoc(docRef, gameData);
}

export async function deleteGame(id: string): Promise<void> {
  await deleteDoc(doc(db, "games", id));
}

// ─── Categories ───────────────────────────────────────────────────────────────
export async function getCategories(): Promise<Category[]> {
  const q = query(collection(db, "categories"), orderBy("name", "asc"));
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Category));
}

export async function createCategory(catData: Omit<Category, "id" | "createdAt">): Promise<string> {
  const docRef = await addDoc(collection(db, "categories"), {
    ...catData,
    createdAt: Date.now(),
  });
  return docRef.id;
}

export async function updateCategory(id: string, catData: Partial<Category>): Promise<void> {
  const docRef = doc(db, "categories", id);
  await updateDoc(docRef, catData);
}

export async function deleteCategory(id: string): Promise<void> {
  await deleteDoc(doc(db, "categories", id));
}
