import { useEffect, useState } from "react";
import { auth, googleProvider } from "@/lib/firebase";
import {
  signInWithPopup,
  signOut,
  onAuthStateChanged,
} from "firebase/auth";

export interface AuthUser {
  uid: string;
  email?: string;
  displayName?: string;
  role: "admin" | "user";
}

export function useFirebaseAuth() {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        const adminEmail = "thiagofernandesribeiroalvss@gmail.com";
        if (currentUser.email !== adminEmail) {
          await signOut(auth);
          setUser(null);
          setLoading(false);
          return;
        }
        const { getUserRole } = await import("@/lib/firebaseHelpers");
        const role = await getUserRole(currentUser.uid, currentUser.email || undefined);
        setUser({
          uid: currentUser.uid,
          email: currentUser.email || undefined,
          displayName: currentUser.displayName || undefined,
          role,
        });
      } else {
        setUser(null);
      }
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const loginWithGoogle = async () => {
    try {
      setError(null);
      const result = await signInWithPopup(auth, googleProvider);
      const { getUserRole } = await import("@/lib/firebaseHelpers");
      const role = await getUserRole(result.user.uid, result.user.email || undefined);
      setUser({
        uid: result.user.uid,
        email: result.user.email || undefined,
        displayName: result.user.displayName || undefined,
        role,
      });
      return result.user;
    } catch (err: any) {
      const msg = err?.message ?? "Erro ao fazer login";
      setError(msg);
      throw err;
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
      setUser(null);
    } catch (err: any) {
      setError(err?.message ?? "Erro ao fazer logout");
    }
  };

  return {
    user,
    loading,
    error,
    loginWithGoogle,
    logout,
    isAuthenticated: !!user,
    isAdmin: user?.role === "admin",
  };
}
