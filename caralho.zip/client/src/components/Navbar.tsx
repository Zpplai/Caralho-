import { useFirebaseAuth } from "@/hooks/useFirebaseAuth";
import { Search, Shield, LogOut, Menu, X } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";

interface NavbarProps {
  onSearch?: (q: string) => void;
  searchValue?: string;
}

export function Navbar({ onSearch, searchValue = "" }: NavbarProps) {
  const { user, isAuthenticated, isAdmin, logout, loginWithGoogle } = useFirebaseAuth();
  const [, navigate] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [localSearch, setLocalSearch] = useState(searchValue);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) onSearch(localSearch);
  };

  const handleLogout = async (e: React.MouseEvent) => {
    e.preventDefault();
    await logout();
    setMenuOpen(false);
  };

  const handleLogin = async () => {
    try {
      await loginWithGoogle();
    } catch (err) {
      console.error("Login error:", err);
    }
  };

  return (
    <nav className="sticky top-0 z-50 bg-card border-b border-border/50 shadow-md">
      <div className="container flex items-center justify-between h-16 gap-4">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-1 shrink-0">
          <span className="font-display text-3xl text-foreground leading-none">GAMES</span>
          <span className="font-display text-3xl text-primary leading-none">360</span>
        </Link>

        {/* Search — desktop */}
        <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-xs">
          <div className="flex w-full rounded-lg overflow-hidden border border-border/50 focus-within:ring-2 focus-within:ring-primary transition-all">
            <input
              type="text"
              placeholder="Buscar jogos..."
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              className="flex-1 bg-input text-foreground text-sm px-4 py-2 outline-none placeholder:text-muted-foreground truncate"
            />
            <button
              type="submit"
              className="bg-primary text-primary-foreground px-4 py-2 hover:bg-primary/90 transition-colors shrink-0"
            >
              <Search size={18} />
            </button>
          </div>
        </form>

        {/* Right actions */}
        <div className="hidden md:flex items-center gap-2">
          {isAdmin && (
            <Link
              href="/admin"
              className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-primary hover:text-primary/80 transition-colors px-3 py-2 rounded-lg hover:bg-primary/10"
            >
              <Shield size={16} />
              ADMIN
            </Link>
          )}
          {isAuthenticated ? (
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors px-3 py-2 rounded-lg hover:bg-muted"
            >
              <LogOut size={16} />
              SAIR
            </button>
          ) : (
            <button
              onClick={(e) => { e.preventDefault(); handleLogin(); }}
              className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-foreground bg-primary hover:bg-primary/90 transition-colors px-4 py-2 rounded-lg shrink-0"
            >
              <Shield size={16} />
              LOGIN
            </button>
          )}
        </div>

        {/* Mobile menu toggle */}
        <button
          className="md:hidden text-foreground"
          onClick={() => setMenuOpen((v) => !v)}
        >
          {menuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden border-t border-border/50 bg-card px-4 py-4 flex flex-col gap-3">
          <form onSubmit={handleSearch} className="flex rounded-lg overflow-hidden border border-border/50">
            <input
              type="text"
              placeholder="Buscar..."
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              className="flex-1 bg-input text-foreground text-sm px-3 py-2 outline-none placeholder:text-muted-foreground"
            />
            <button type="submit" className="bg-primary text-primary-foreground px-3 py-2">
              <Search size={16} />
            </button>
          </form>
          {isAdmin && (
            <Link
              href="/admin"
              className="text-xs font-bold uppercase tracking-widest text-primary px-3 py-2 rounded-lg hover:bg-primary/10"
              onClick={() => setMenuOpen(false)}
            >
              PAINEL ADMIN
            </Link>
          )}
          {isAuthenticated ? (
            <button
              onClick={() => { logout(); setMenuOpen(false); }}
              className="text-left text-xs font-bold uppercase tracking-widest text-muted-foreground px-3 py-2 rounded-lg hover:bg-muted"
            >
              SAIR
            </button>
          ) : (
            <button
              onClick={() => { handleLogin(); setMenuOpen(false); }}
              className="text-left text-xs font-bold uppercase tracking-widest text-foreground bg-primary hover:bg-primary/90 px-3 py-2 rounded-lg"
            >
              LOGIN
            </button>
          )}
        </div>
      )}
    </nav>
  );
}
