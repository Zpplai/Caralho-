import { Download, Star } from "lucide-react";
import { Link } from "wouter";

interface GameCardProps {
  id: string;
  title: string;
  coverUrl?: string | null;
  categoryName?: string | null;
  downloadUrl?: string | null;
  featured?: boolean;
}

export function GameCard({
  id,
  title,
  coverUrl,
  categoryName,
  downloadUrl,
  featured,
}: GameCardProps) {
  return (
    <Link href={`/game/${id}`}>
      <div className="group relative flex flex-col bg-card rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all hover:scale-105 cursor-pointer border border-border/30">
        {/* Cover */}
        <div className="relative aspect-[3/4] bg-gradient-to-br from-muted to-muted/50 overflow-hidden">
          {coverUrl ? (
            <img src={coverUrl} alt={title} className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <span className="font-display text-6xl text-muted-foreground/30">360</span>
            </div>
          )}
          
          {/* Featured badge */}
          {featured && (
            <div className="absolute top-2 right-2 bg-primary text-primary-foreground rounded-full p-2 shadow-lg">
              <Star size={14} fill="currentColor" />
            </div>
          )}

          {/* Category badge */}
          {categoryName && (
            <div className="absolute top-2 left-2 bg-primary/90 text-primary-foreground text-xs font-bold px-3 py-1 rounded-full uppercase tracking-widest">
              {categoryName}
            </div>
          )}

          {/* Overlay on hover */}
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
            <Download className="text-white" size={32} />
          </div>
        </div>

        {/* Info */}
        <div className="p-3 flex-1 flex flex-col justify-between">
          <p className="font-semibold text-sm line-clamp-2 text-foreground group-hover:text-primary transition-colors">
            {title}
          </p>
          {downloadUrl && (
            <button
              onClick={(e) => {
                e.preventDefault();
                window.open(downloadUrl, "_blank");
              }}
              className="mt-2 text-xs font-bold uppercase tracking-widest text-primary hover:text-primary/80 transition-colors"
            >
              BAIXAR
            </button>
          )}
        </div>
      </div>
    </Link>
  );
}
