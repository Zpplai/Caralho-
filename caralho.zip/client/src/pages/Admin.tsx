import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import { toast } from "sonner";
import { useFirebaseAuth } from "@/hooks/useFirebaseAuth";
import {
  Plus, MoreVertical, Trash2, Shield, LogOut, Upload, Gamepad2, Tag, Star, StarOff, Loader2, Pencil,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  getGames, createGame, updateGame, deleteGame,
  getCategories, createCategory, updateCategory, deleteCategory,
  type Game, type Category,
} from "@/lib/firebaseHelpers";
import { storage } from "@/lib/firebaseStorage";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";

type GameForm = {
  title: string;
  description: string;
  categoryId: string;
  downloadUrl: string;
  featured: boolean;
  coverUrl: string;
};

const emptyGame: GameForm = {
  title: "", description: "", categoryId: "", downloadUrl: "",
  featured: false, coverUrl: "",
};

type CategoryForm = { name: string; slug: string };
const emptyCat: CategoryForm = { name: "", slug: "" };

// ─── Upload helper ────────────────────────────────────────────────────────────
function useImageUpload() {
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  const upload = async (file: File): Promise<string | null> => {
    setUploading(true);
    try {
      const storageRef = ref(storage, `covers/${Date.now()}_${file.name}`);
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);
      setPreview(url);
      return url;
    } catch {
      toast.error("Erro ao fazer upload da imagem.");
      return null;
    } finally {
      setUploading(false);
    }
  };

  return { upload, uploading, preview, setPreview };
}

// ─── Game Form Modal ──────────────────────────────────────────────────────────
function GameModal({
  open, onClose, initial, categories, onSave,
}: {
  open: boolean;
  onClose: () => void;
  initial: (GameForm & { id?: string }) | null;
  categories: Category[];
  onSave: (form: GameForm & { id?: string }) => Promise<void>;
}) {
  const [form, setForm] = useState<GameForm & { id?: string }>(initial || { ...emptyGame });
  const [saving, setSaving] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const { upload, uploading, preview, setPreview } = useImageUpload();

  const set = (k: keyof GameForm, v: string | boolean) =>
    setForm((f) => ({ ...f, [k]: v }));

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await upload(file);
    if (url) set("coverUrl", url);
  };

  const handleSave = async () => {
    if (!form.title.trim()) { toast.error("Título obrigatório."); return; }
    setSaving(true);
    try { await onSave(form); onClose(); }
    catch { toast.error("Erro ao salvar jogo."); }
    finally { setSaving(false); }
  };

  useEffect(() => {
    if (open && initial) {
      setForm(initial);
      setPreview(initial.coverUrl || null);
    }
  }, [open, initial]);

  if (!form) return null;

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="bg-card border-2 border-border text-foreground max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-4xl uppercase">
            {form.id ? "EDITAR JOGO" : "NOVO JOGO"}
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col gap-4 py-4">
          <div
            className="relative aspect-video bg-muted border-2 border-border flex items-center justify-center cursor-pointer hover:border-primary transition-colors overflow-hidden"
            onClick={() => fileRef.current?.click()}
          >
            {preview ? (
              <img src={preview} alt="capa" className="w-full h-full object-cover" />
            ) : (
              <div className="flex flex-col items-center gap-2 text-muted-foreground">
                <Upload size={32} />
                <span className="text-xs uppercase tracking-widest font-bold">UPLOAD</span>
              </div>
            )}
            {uploading && (
              <div className="absolute inset-0 bg-background/70 flex items-center justify-center">
                <span className="text-xs uppercase tracking-widest font-bold animate-pulse">ENVIANDO...</span>
              </div>
            )}
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />
          </div>

          <Input
            placeholder="TÍTULO"
            value={form.title}
            onChange={(e) => set("title", e.target.value)}
            className="bg-input border-2 border-border text-foreground uppercase placeholder:text-muted-foreground font-bold"
          />

          <Textarea
            placeholder="DESCRIÇÃO"
            value={form.description}
            onChange={(e) => set("description", e.target.value)}
            className="bg-input border-2 border-border text-foreground placeholder:text-muted-foreground resize-none"
            rows={3}
          />

          <Select
            value={form.categoryId || "none"}
            onValueChange={(v) => set("categoryId", v === "none" ? "" : v)}
          >
            <SelectTrigger className="bg-input border-2 border-border text-foreground uppercase font-bold">
              <SelectValue placeholder="CATEGORIA" />
            </SelectTrigger>
            <SelectContent className="bg-popover border-2 border-border text-foreground">
              <SelectItem value="none">SEM CATEGORIA</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c.id} value={c.id}>{c.name.toUpperCase()}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Input
            placeholder="LINK DE DOWNLOAD"
            value={form.downloadUrl}
            onChange={(e) => set("downloadUrl", e.target.value)}
            className="bg-input border-2 border-border text-foreground placeholder:text-muted-foreground"
          />

          <button
            type="button"
            onClick={() => set("featured", !form.featured)}
            className={`flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-widest px-4 py-2 border-2 transition-colors ${
              form.featured
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-transparent text-muted-foreground border-border hover:border-primary"
            }`}
          >
            {form.featured ? <Star size={14} /> : <StarOff size={14} />}
            {form.featured ? "RECOMENDADO" : "MARCAR"}
          </button>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose} className="border-2 border-border text-foreground">
            CANCELAR
          </Button>
          <Button
            onClick={handleSave}
            disabled={saving || uploading}
            className="bg-primary text-primary-foreground font-bold uppercase tracking-widest hover:bg-primary/80"
          >
            {saving ? "SALVANDO..." : "SALVAR"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Category Form Modal ──────────────────────────────────────────────────────
function CategoryModal({
  open, onClose, initial, onSave,
}: {
  open: boolean;
  onClose: () => void;
  initial: (CategoryForm & { id?: string }) | null;
  onSave: (form: CategoryForm & { id?: string }) => Promise<void>;
}) {
  const [form, setForm] = useState(initial || { ...emptyCat });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!form.name.trim() || !form.slug.trim()) { toast.error("Nome e slug obrigatórios."); return; }
    setSaving(true);
    try { await onSave(form); onClose(); }
    catch (e: any) { toast.error(e?.message ?? "Erro ao salvar categoria."); }
    finally { setSaving(false); }
  };

  useEffect(() => {
    if (open && initial) setForm(initial);
  }, [open, initial]);

  if (!form) return null;

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="bg-card border-2 border-border text-foreground max-w-sm">
        <DialogHeader>
          <DialogTitle className="font-display text-4xl uppercase">
            {form.id ? "EDITAR" : "NOVA CATEGORIA"}
          </DialogTitle>
        </DialogHeader>
        <div className="flex flex-col gap-3 py-4">
          <Input
            placeholder="NOME"
            value={form.name}
            onChange={(e) => {
              const name = e.target.value;
              setForm((f) => ({
                ...f,
                name,
                slug: f.id ? f.slug : name.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, ""),
              }));
            }}
            className="bg-input border-2 border-border text-foreground uppercase placeholder:text-muted-foreground font-bold"
          />
          <Input
            placeholder="SLUG"
            value={form.slug}
            onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))}
            className="bg-input border-2 border-border text-foreground placeholder:text-muted-foreground"
          />
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose} className="border-2 border-border text-foreground">CANCELAR</Button>
          <Button onClick={handleSave} disabled={saving} className="bg-primary text-primary-foreground font-bold uppercase tracking-widest hover:bg-primary/80">
            {saving ? "SALVANDO..." : "SALVAR"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Game Menu ────────────────────────────────────────────────────────────────
function GameMenu({ game, onEdit, onDelete }: { game: Game; onEdit: () => void; onDelete: () => void }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="p-1 text-muted-foreground hover:text-foreground transition-colors"
      >
        <MoreVertical size={18} />
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-1 bg-card border-2 border-border shadow-lg z-50 min-w-[120px]">
          <button
            onClick={() => { onEdit(); setOpen(false); }}
            className="w-full text-left px-3 py-2 text-xs font-bold uppercase tracking-widest text-foreground hover:bg-muted transition-colors flex items-center gap-2 border-b border-border"
          >
            <Pencil size={12} />
            EDITAR
          </button>
          <button
            onClick={() => { onDelete(); setOpen(false); }}
            className="w-full text-left px-3 py-2 text-xs font-bold uppercase tracking-widest text-primary hover:bg-muted transition-colors flex items-center gap-2"
          >
            <Trash2 size={12} />
            REMOVER
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Main Admin Page ──────────────────────────────────────────────────────────
export default function Admin() {
  const { user, loading, isAdmin, logout } = useFirebaseAuth();
  const [tab, setTab] = useState<"games" | "categories">("games");

  const [games, setGames] = useState<Game[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  const [gameModal, setGameModal] = useState(false);
  const [editGame, setEditGame] = useState<(GameForm & { id?: string }) | null>(null);
  const [deleteGameId, setDeleteGameId] = useState<string | null>(null);

  const [catModal, setCatModal] = useState(false);
  const [editCat, setEditCat] = useState<(CategoryForm & { id?: string }) | null>(null);
  const [deleteCatId, setDeleteCatId] = useState<string | null>(null);

  // Load data
  useEffect(() => {
    if (!user) return;
    (async () => {
      try {
        const [g, c] = await Promise.all([getGames(), getCategories()]);
        setGames(g);
        setCategories(c);
      } catch (e) {
        toast.error("Erro ao carregar dados.");
      } finally {
        setLoadingData(false);
      }
    })();
  }, [user]);

  // Game handlers
  const handleGameSave = async (form: GameForm & { id?: string }) => {
    try {
      if (form.id) {
        await updateGame(form.id, form);
        setGames((g) => g.map((x) => (x.id === form.id ? { ...x, ...form } : x)));
        toast.success("Jogo atualizado!");
      } else {
        const id = await createGame(form);
        const cat = categories.find((c) => c.id === form.categoryId);
        setGames((g) => [{ ...form, id, categoryName: cat?.name } as Game, ...g]);
        toast.success("Jogo adicionado!");
      }
    } catch (e) {
      toast.error("Erro ao salvar jogo.");
    }
  };

  const handleGameDelete = async (id: string) => {
    try {
      await deleteGame(id);
      setGames((g) => g.filter((x) => x.id !== id));
      toast.success("Jogo removido!");
    } catch {
      toast.error("Erro ao remover jogo.");
    }
  };

  // Category handlers
  const handleCatSave = async (form: CategoryForm & { id?: string }) => {
    try {
      if (form.id) {
        await updateCategory(form.id, form);
        setCategories((c) => c.map((x) => (x.id === form.id ? { ...x, ...form } : x)));
        toast.success("Categoria atualizada!");
      } else {
        const id = await createCategory(form);
        setCategories((c) => [...c, { ...form, id, createdAt: Date.now() }]);
        toast.success("Categoria criada!");
      }
    } catch (e) {
      toast.error("Erro ao salvar categoria.");
    }
  };

  const handleCatDelete = async (id: string) => {
    try {
      await deleteCategory(id);
      setCategories((c) => c.filter((x) => x.id !== id));
      toast.success("Categoria removida!");
    } catch {
      toast.error("Erro ao remover categoria.");
    }
  };

  // Auth guard
  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="animate-spin text-primary" size={32} />
      </div>
    );
  }

  if (!user || !isAdmin) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-6">
        <div className="w-full h-1 bg-primary absolute top-0 left-0" />
        <span className="font-display text-6xl text-foreground text-center">ACESSO RESTRITO</span>
        <p className="text-muted-foreground uppercase tracking-widest text-sm">Você não tem permissão para acessar esta área.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b-4 border-primary sticky top-0 z-50 bg-background">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="font-display text-3xl text-foreground">
            GAMES<span className="text-primary">360</span>
          </Link>
          <button
            onClick={logout}
            className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors"
          >
            <LogOut size={14} />
            SAIR
          </button>
        </div>
      </header>

      <div className="container py-8">
        <div className="flex gap-0 border-b-4 border-border mb-8">
          <button
            onClick={() => setTab("games")}
            className={`flex items-center gap-2 px-6 py-3 text-sm font-bold uppercase tracking-widest border-b-4 transition-colors ${
              tab === "games" ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <Gamepad2 size={16} />
            JOGOS ({games.length})
          </button>
          <button
            onClick={() => setTab("categories")}
            className={`flex items-center gap-2 px-6 py-3 text-sm font-bold uppercase tracking-widest border-b-4 transition-colors ${
              tab === "categories" ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <Tag size={16} />
            CATEGORIAS ({categories.length})
          </button>
        </div>

        {/* Games Tab */}
        {tab === "games" && (
          <div>
            <div className="flex items-center justify-between mb-8 gap-4">
              <h2 className="font-display text-5xl">JOGOS</h2>
              <Button
                onClick={() => { setEditGame({ ...emptyGame }); setGameModal(true); }}
                className="flex items-center gap-2 bg-primary text-primary-foreground font-bold uppercase tracking-widest hover:bg-primary/80 text-sm px-4 py-2 rounded-lg shrink-0"
              >
                <Plus size={20} />
                ADICIONAR JOGO
              </Button>
            </div>

            {loadingData ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div key={i} className="aspect-[3/4] bg-muted animate-pulse border-2 border-border" />
                ))}
              </div>
            ) : games.length === 0 ? (
              <div className="py-20 text-center border-2 border-dashed border-border">
                <p className="font-display text-4xl text-muted-foreground">NENHUM JOGO</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {games.map((g) => (
                  <div key={g.id} className="group relative flex flex-col bg-card border-2 border-border hover:border-primary transition-colors">
                    <div className="absolute top-2 left-2 z-10">
                      <GameMenu
                        game={g}
                        onEdit={() => {
                          setEditGame({
                            id: g.id,
                            title: g.title,
                            description: g.description,
                            categoryId: g.categoryId,
                            downloadUrl: g.downloadUrl,
                            featured: g.featured,
                            coverUrl: g.coverUrl,
                          });
                          setGameModal(true);
                        }}
                        onDelete={() => setDeleteGameId(g.id)}
                      />
                    </div>
                    <div className="aspect-[3/4] bg-muted overflow-hidden relative">
                      {g.coverUrl ? (
                        <img src={g.coverUrl} alt={g.title} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <span className="font-display text-5xl text-muted-foreground">360</span>
                        </div>
                      )}
                      {g.featured && <span className="absolute bottom-2 right-2 bg-primary text-primary-foreground p-1.5"><Star size={14} fill="currentColor" /></span>}
                    </div>
                    <div className="p-3 flex-1">
                      <p className="font-display text-sm leading-tight line-clamp-2">{g.title}</p>
                      {g.categoryName && <p className="text-xs text-muted-foreground uppercase tracking-widest mt-1">{g.categoryName}</p>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Categories Tab */}
        {tab === "categories" && (
          <div>
            <div className="flex items-center justify-between mb-8">
              <h2 className="font-display text-5xl">CATEGORIAS</h2>
              <Button
                onClick={() => { setEditCat({ ...emptyCat }); setCatModal(true); }}
                className="flex items-center gap-2 bg-primary text-primary-foreground font-bold uppercase tracking-widest hover:bg-primary/80 text-sm"
              >
                <Plus size={16} />
                NOVA CATEGORIA
              </Button>
            </div>

            {loadingData ? (
              <div className="space-y-2">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="h-14 bg-muted animate-pulse border-2 border-border" />
                ))}
              </div>
            ) : categories.length === 0 ? (
              <div className="py-20 text-center border-2 border-dashed border-border">
                <p className="font-display text-4xl text-muted-foreground">NENHUMA CATEGORIA</p>
              </div>
            ) : (
              <div className="flex flex-col gap-0 border-2 border-border">
                {categories.map((cat, i) => (
                  <div key={cat.id} className={`flex items-center justify-between px-4 py-3 ${i > 0 ? "border-t-2 border-border" : ""}`}>
                    <div>
                      <p className="font-bold uppercase tracking-widest text-foreground">{cat.name}</p>
                      <p className="text-xs text-muted-foreground">{cat.slug}</p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => { setEditCat({ id: cat.id, name: cat.name, slug: cat.slug }); setCatModal(true); }}
                        className="flex items-center gap-1 text-xs font-bold uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors px-3 py-1 border-2 border-border hover:border-primary"
                      >
                        <Pencil size={12} />
                        EDITAR
                      </button>
                      <button
                        onClick={() => setDeleteCatId(cat.id)}
                        className="flex items-center gap-1 text-xs font-bold uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors px-3 py-1 border-2 border-border hover:border-primary"
                      >
                        <Trash2 size={12} />
                        REMOVER
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {editGame && (
        <GameModal
          open={gameModal}
          onClose={() => { setGameModal(false); setEditGame(null); }}
          initial={editGame}
          categories={categories}
          onSave={handleGameSave}
        />
      )}

      {editCat && (
        <CategoryModal
          open={catModal}
          onClose={() => { setCatModal(false); setEditCat(null); }}
          initial={editCat}
          onSave={handleCatSave}
        />
      )}

      <AlertDialog open={deleteGameId !== null} onOpenChange={(o) => { if (!o) setDeleteGameId(null); }}>
        <AlertDialogContent className="bg-card border-2 border-border text-foreground">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-4xl uppercase">REMOVER JOGO?</AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">Esta ação não pode ser desfeita.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-2 border-border text-foreground bg-transparent">CANCELAR</AlertDialogCancel>
            <AlertDialogAction
              className="bg-primary text-primary-foreground font-bold uppercase tracking-widest hover:bg-primary/80"
              onClick={async () => {
                if (deleteGameId) {
                  await handleGameDelete(deleteGameId);
                  setDeleteGameId(null);
                }
              }}
            >
              REMOVER
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={deleteCatId !== null} onOpenChange={(o) => { if (!o) setDeleteCatId(null); }}>
        <AlertDialogContent className="bg-card border-2 border-border text-foreground">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-4xl uppercase">REMOVER CATEGORIA?</AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">Os jogos ficarão sem categoria.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-2 border-border text-foreground bg-transparent">CANCELAR</AlertDialogCancel>
            <AlertDialogAction
              className="bg-primary text-primary-foreground font-bold uppercase tracking-widest hover:bg-primary/80"
              onClick={async () => {
                if (deleteCatId) {
                  await handleCatDelete(deleteCatId);
                  setDeleteCatId(null);
                }
              }}
            >
              REMOVER
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
