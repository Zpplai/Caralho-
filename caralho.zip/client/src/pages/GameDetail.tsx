import { Navbar } from "@/components/Navbar";
import { Download, ArrowLeft, Tag, Loader2 } from "lucide-react";
import { Link, useParams } from "wouter";
import { useEffect, useState } from "react";
import { getGameById, type Game } from "@/lib/firebaseHelpers";

export default function GameDetail() {
  const { id } = useParams<{ id: string }>();
  const [game, setGame] = useState<Game | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    (async () => {
      try {
        const g = await getGameById(id);
        setGame(g);
      } catch (e) {
        console.error("Erro ao carregar jogo:", e);
      } finally {
        setLoading(false);
      }
    })();
  }, [id]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />

      <div className="container py-8">
        <Link href="/" className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors mb-8">
          <ArrowLeft size={14} />
          VOLTAR
        </Link>

        {loading && (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="animate-spin text-primary" size={32} />
          </div>
        )}

        {game && (
          <div className="grid md:grid-cols-[300px_1fr] gap-8">
            <div className="aspect-[3/4] bg-muted overflow-hidden border border-border">
              {game.coverUrl ? (
                <img src={game.coverUrl} alt={game.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <span className="font-display text-6xl text-muted-foreground">360</span>
                </div>
              )}
            </div>

            <div className="flex flex-col gap-4">
              {game.categoryName && (
                <span className="inline-flex items-center gap-1 text-xs font-bold uppercase tracking-widest text-primary">
                  <Tag size={12} />
                  {game.categoryName}
                </span>
              )}
              <h1 className="font-display text-5xl md:text-7xl leading-none text-foreground">
                {game.title}
              </h1>
              <div className="w-24 h-1 bg-primary" />

              {game.description && (
                <p className="text-muted-foreground leading-relaxed max-w-2xl">
                  {game.description}
                </p>
              )}

              <div className="mt-4">
                {game.downloadUrl ? (
                  <a
                    href={game.downloadUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-3 bg-primary text-primary-foreground font-bold text-sm uppercase tracking-widest py-4 px-8 hover:bg-primary/80 transition-colors"
                  >
                    <Download size={18} />
                    BAIXAR AGORA
                  </a>
                ) : (
                  <span className="inline-flex items-center gap-3 bg-muted text-muted-foreground text-sm uppercase tracking-widest py-4 px-8">
                    DOWNLOAD INDISPONÍVEL
                  </span>
                )}
              </div>

              <p className="text-xs text-muted-foreground uppercase tracking-widest mt-auto">
                Adicionado em {new Date(game.createdAt).toLocaleDateString("pt-BR")}
              </p>
            </div>
          </div>
        )}

        {!loading && !game && (
          <div className="py-20 text-center">
            <p className="font-display text-5xl text-muted-foreground">JOGO NÃO ENCONTRADO</p>
          </div>
        )}
      </div>
    </div>
  );
}
