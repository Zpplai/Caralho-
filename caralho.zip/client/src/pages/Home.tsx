import { GameCard } from "@/components/GameCard";
import { Navbar } from "@/components/Navbar";
import { useState, useEffect } from "react";
import { getGames, getFeaturedGames, type Game } from "@/lib/firebaseHelpers";
import { getCategories, type Category } from "@/lib/firebaseHelpers";
import { Loader2 } from "lucide-react";

function GameGrid({ games, loading }: { games: Game[]; loading: boolean }) {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="animate-spin text-primary" size={32} />
      </div>
    );
  }
  if (!games.length) {
    return (
      <div className="py-16 text-center">
        <p className="font-display text-3xl text-muted-foreground mb-2">Nenhum jogo encontrado</p>
        <p className="text-sm text-muted-foreground">Tente ajustar seus filtros ou pesquisa</p>
      </div>
    );
  }
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
      {games.map((g) => (
        <GameCard
          key={g.id}
          id={g.id}
          title={g.title}
          coverUrl={g.coverUrl}
          categoryName={g.categoryName}
          downloadUrl={g.downloadUrl}
          featured={g.featured}
        />
      ))}
    </div>
  );
}

export default function Home() {
  const [search, setSearch] = useState("");
  const [activeCategoryId, setActiveCategoryId] = useState<string | undefined>(undefined);

  const [categories, setCategories] = useState<Category[]>([]);
  const [featured, setFeatured] = useState<Game[]>([]);
  const [games, setGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);

  // Load categories
  useEffect(() => {
    (async () => {
      try {
        const cats = await getCategories();
        setCategories(cats);
      } catch (e) {
        console.error("Erro ao carregar categorias:", e);
      }
    })();
  }, []);

  // Load featured games
  useEffect(() => {
    (async () => {
      try {
        const feat = await getFeaturedGames();
        setFeatured(feat);
      } catch (e) {
        console.error("Erro ao carregar recomendados:", e);
      }
    })();
  }, []);

  // Load games with filters
  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const g = await getGames({ categoryId: activeCategoryId, search: search || undefined });
        setGames(g);
      } catch (e) {
        console.error("Erro ao carregar jogos:", e);
      } finally {
        setLoading(false);
      }
    })();
  }, [activeCategoryId, search]);

  const showFeatured = !search && !activeCategoryId;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar onSearch={setSearch} searchValue={search} />

      {showFeatured && (
        <section className="border-b border-border/50 bg-gradient-to-br from-card to-background">
          <div className="container py-12 md:py-20">
            <p className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-4">
              Catálogo Completo
            </p>
            <h1 className="font-display text-6xl md:text-8xl leading-tight text-foreground mb-6">
              GAMES<br />
              <span className="text-primary">360</span>
            </h1>
            <p className="text-muted-foreground text-sm max-w-lg leading-relaxed">
              Descubra e baixe os melhores jogos. Catálogo completo, atualizado e organizado por categoria.
            </p>
          </div>
        </section>
      )}

      {showFeatured && featured.length > 0 && (
        <section className="border-b border-border/50">
          <div className="container py-12">
            <h2 className="font-display text-4xl text-foreground mb-8">Recomendados</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {featured.map((g) => (
                <GameCard
                  key={g.id}
                  id={g.id}
                  title={g.title}
                  coverUrl={g.coverUrl}
                  categoryName={g.categoryName}
                  downloadUrl={g.downloadUrl}
                  featured={true}
                />
              ))}
            </div>
          </div>
        </section>
      )}

      <section className="container py-12">
        <div className="mb-8">
          <h2 className="font-display text-4xl text-foreground mb-6">
            {search ? `Resultados: "${search}"` : "Todos os Jogos"}
          </h2>

          {!search && (
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setActiveCategoryId(undefined)}
                className={`px-4 py-2 text-xs font-bold uppercase tracking-widest rounded-lg transition-all ${
                  !activeCategoryId
                    ? "bg-primary text-primary-foreground shadow-lg"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                Todos
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategoryId(cat.id)}
                  className={`px-4 py-2 text-xs font-bold uppercase tracking-widest rounded-lg transition-all ${
                    activeCategoryId === cat.id
                      ? "bg-primary text-primary-foreground shadow-lg"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          )}
        </div>

        <GameGrid games={games} loading={loading} />
      </section>

      <footer className="border-t border-border/50 bg-card mt-16">
        <div className="container py-8 flex items-center justify-between text-sm text-muted-foreground">
          <span className="font-display text-lg text-foreground">
            GAMES<span className="text-primary">360</span>
          </span>
          <span>© {new Date().getFullYear()} — Todos os direitos reservados</span>
        </div>
      </footer>
    </div>
  );
}
